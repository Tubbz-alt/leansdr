var structleansdr_1_1nearest__sampler =
[
    [ "interp", "structleansdr_1_1nearest__sampler.html#abfb4905f33d2a2603c5f491e35951564", null ],
    [ "readahead", "structleansdr_1_1nearest__sampler.html#a6ecbffbfe055302ca4ac588302992a24", null ]
];