var structleansdr_1_1decimator =
[
    [ "decimator", "structleansdr_1_1decimator.html#a061573205452b1508ff27750e6df51b6", null ],
    [ "run", "structleansdr_1_1decimator.html#add6a14d88b1d88c00d674612da7bb34a", null ],
    [ "d", "structleansdr_1_1decimator.html#a46efaeec5bfbe0ed694aa4f068c1ea1f", null ]
];