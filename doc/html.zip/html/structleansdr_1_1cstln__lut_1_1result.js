var structleansdr_1_1cstln__lut_1_1result =
[
    [ "phase_error", "structleansdr_1_1cstln__lut_1_1result.html#a505143c2500bcbbbd3faa7939963bc2b", null ],
    [ "ss", "structleansdr_1_1cstln__lut_1_1result.html#a46992c1d7cd850451254e14404d81609", null ]
];