var structleansdr_1_1auto__notch =
[
    [ "auto_notch", "structleansdr_1_1auto__notch.html#ad387a2fa96b3c6f9c4b480d45feb819d", null ],
    [ "detect", "structleansdr_1_1auto__notch.html#a1a5bcfae1ed16f9ff7a1ad04aa778fb6", null ],
    [ "process", "structleansdr_1_1auto__notch.html#adad5d6f789c374b4a8a2e2c21302fb37", null ],
    [ "run", "structleansdr_1_1auto__notch.html#a2274e1afa4f2b1cc6eb5399059c4702b", null ],
    [ "decimation", "structleansdr_1_1auto__notch.html#aa4540619c07f312251003256be45989a", null ],
    [ "k", "structleansdr_1_1auto__notch.html#af389bf792345a2046cbe680854eeebd0", null ]
];