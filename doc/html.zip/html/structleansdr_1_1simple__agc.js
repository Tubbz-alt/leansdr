var structleansdr_1_1simple__agc =
[
    [ "simple_agc", "structleansdr_1_1simple__agc.html#a8c1cc9acfc648d1afebacf096bc076d8", null ],
    [ "bw", "structleansdr_1_1simple__agc.html#a38b23784b98fe0b696ab929e0f5f63e2", null ],
    [ "estimated", "structleansdr_1_1simple__agc.html#a35eb11ef7a2d9a0bedb8a1bdf610df44", null ],
    [ "out_rms", "structleansdr_1_1simple__agc.html#a77792c0e24d5e0bc31caee06672ff88b", null ]
];