var structleansdr_1_1adder =
[
    [ "adder", "structleansdr_1_1adder.html#a180a8fc4a9d749bca83c3b2143c2e755", null ],
    [ "run", "structleansdr_1_1adder.html#a9c1bcf3aa84a5391fd449999e9634b5c", null ]
];