var structleansdr_1_1serializer =
[
    [ "serializer", "structleansdr_1_1serializer.html#ad42494159b2445926364ac66c2ac1e37", null ],
    [ "run", "structleansdr_1_1serializer.html#aa7e3b0d0b3483414fd36b14db436e45f", null ]
];