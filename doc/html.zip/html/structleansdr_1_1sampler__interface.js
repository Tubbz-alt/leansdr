var structleansdr_1_1sampler__interface =
[
    [ "interp", "structleansdr_1_1sampler__interface.html#a409095111fe20d14350f7801dd6b033e", null ],
    [ "readahead", "structleansdr_1_1sampler__interface.html#a093ceff6a6169ae33bf5d27c941c5b13", null ],
    [ "update_freq", "structleansdr_1_1sampler__interface.html#a325181a5c9136a03deb58dc1e4c99d6f", null ]
];