var leandvb_8cc =
[
    [ "config", "structconfig.html", "structconfig" ],
    [ "ALGEBRAIC_COMPAT", "leandvb_8cc.html#a6be035784255035f7ed034b368719d0e", null ],
    [ "decimation", "leandvb_8cc.html#a31f6738ef8868571da4699675a3e2a3e", null ],
    [ "main", "leandvb_8cc.html#ac0f2228420376f4db7e1274f2b41667c", null ],
    [ "run", "leandvb_8cc.html#a9c0fbbc7740901d3735b488b6aeda882", null ],
    [ "run_highspeed", "leandvb_8cc.html#a64180c828eb7c87a76ff32f2dfeee28e", null ],
    [ "usage", "leandvb_8cc.html#af719bcfc0aedeee9d85458e65cde6c74", null ]
];