var structleansdr_1_1buffer__writer =
[
    [ "buffer_writer", "structleansdr_1_1buffer__writer.html#ae9c7ddfe4245ae67f6aa5b0a707e36c2", null ],
    [ "run", "structleansdr_1_1buffer__writer.html#ada9acac10e988d9ebaa4171fbdef1112", null ]
];