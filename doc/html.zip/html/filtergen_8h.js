var filtergen_8h =
[
    [ "dump_filter", "filtergen_8h.html#a9e57e27876be7ee2e6297cc30ced3408", null ],
    [ "lowpass", "filtergen_8h.html#a090642f96272409893149389f99eab14", null ],
    [ "normalize_dcgain", "filtergen_8h.html#a480e3e48fd65dd33a10a611abe0b6941", null ],
    [ "normalize_power", "filtergen_8h.html#ac7d11609c534ce9b5aac2fa60275ea24", null ],
    [ "root_raised_cosine", "filtergen_8h.html#a348e6e30e5cf85df6739779c86360d55", null ]
];