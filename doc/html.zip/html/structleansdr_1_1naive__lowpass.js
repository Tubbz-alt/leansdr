var structleansdr_1_1naive__lowpass =
[
    [ "naive_lowpass", "structleansdr_1_1naive__lowpass.html#a0b4de7cdccd9d201efe163af8883bbb9", null ],
    [ "run", "structleansdr_1_1naive__lowpass.html#a3f824769c51bde68257c4debdd605300", null ]
];