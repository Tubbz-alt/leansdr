var annotated_dup =
[
    [ "leansdr", "namespaceleansdr.html", "namespaceleansdr" ],
    [ "config", "structconfig.html", "structconfig" ],
    [ "drifter", "structdrifter.html", "structdrifter" ],
    [ "field", "structfield.html", "structfield" ],
    [ "interpolator", "structinterpolator.html", "structinterpolator" ]
];