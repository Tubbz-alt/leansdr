var structleansdr_1_1wgn__c =
[
    [ "wgn_c", "structleansdr_1_1wgn__c.html#a9ce9d335e1c350020bc41cdb5a402914", null ],
    [ "run", "structleansdr_1_1wgn__c.html#ae97644c2a0fde60908a3ed08ce592b8e", null ],
    [ "stddev", "structleansdr_1_1wgn__c.html#a6f515e8b5c7bf7ff63781fac67cac3eb", null ]
];