var structleansdr_1_1fir__filter =
[
    [ "fir_filter", "structleansdr_1_1fir__filter.html#a0d65240d309ccf1bcb7316082c93ea07", null ],
    [ "run", "structleansdr_1_1fir__filter.html#a74bea4ead15f61f03135fe368317a962", null ],
    [ "freq_tap", "structleansdr_1_1fir__filter.html#add982dec7aa6b9201c49c753984004dc", null ],
    [ "freq_tol", "structleansdr_1_1fir__filter.html#aef680784e8ed50232129180c812b8b72", null ],
    [ "tap_multiplier", "structleansdr_1_1fir__filter.html#a3539810e97146b88026b231dbbc88e7a", null ]
];