var convolutional_8h =
[
    [ "deconvol_poly", "structleansdr_1_1deconvol__poly.html", "structleansdr_1_1deconvol__poly" ],
    [ "deconvol_poly2", "structleansdr_1_1deconvol__poly2.html", "structleansdr_1_1deconvol__poly2" ],
    [ "convol_poly2", "structleansdr_1_1convol__poly2.html", "structleansdr_1_1convol__poly2" ],
    [ "LOOP", "convolutional_8h.html#aab3bf876393fe512ad957550e1a4842a", null ]
];