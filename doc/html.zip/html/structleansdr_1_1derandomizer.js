var structleansdr_1_1derandomizer =
[
    [ "derandomizer", "structleansdr_1_1derandomizer.html#a1a9d97f8c9e030fb9b2ae5cb64628b40", null ],
    [ "precompute_pattern", "structleansdr_1_1derandomizer.html#a4da6a30a41bd1a08425da119c48439c4", null ],
    [ "run", "structleansdr_1_1derandomizer.html#a2c5b60fdbc97e12c1612dde0b6978ece", null ]
];