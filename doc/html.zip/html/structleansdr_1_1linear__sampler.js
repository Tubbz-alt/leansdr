var structleansdr_1_1linear__sampler =
[
    [ "interp", "structleansdr_1_1linear__sampler.html#a849333f523283586acbb92f4629de1bc", null ],
    [ "readahead", "structleansdr_1_1linear__sampler.html#ae8a8175322b15a788880988afeff9537", null ],
    [ "update_freq", "structleansdr_1_1linear__sampler.html#a647ca85f64116f5eaa375d4d2d117659", null ]
];