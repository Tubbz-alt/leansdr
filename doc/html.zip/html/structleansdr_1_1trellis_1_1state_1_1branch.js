var structleansdr_1_1trellis_1_1state_1_1branch =
[
    [ "pred", "structleansdr_1_1trellis_1_1state_1_1branch.html#ab7dc20f1dcafa114bbd18dff7a969040", null ],
    [ "us", "structleansdr_1_1trellis_1_1state_1_1branch.html#a900b324595a0c35dc11971999f2ad759", null ]
];