var structleansdr_1_1dvb__deconvol__sync =
[
    [ "decoded_byte", "structleansdr_1_1dvb__deconvol__sync.html#a628033bdc57f14fb13c6b9cbb17f62ec", null ],
    [ "dvb_deconvol_sync", "structleansdr_1_1dvb__deconvol__sync.html#af9949c37446713d171d5e892fae2a591", null ],
    [ "run", "structleansdr_1_1dvb__deconvol__sync.html#a17f47172e96a26fefb344511c0ed93ef", null ],
    [ "resync_period", "structleansdr_1_1dvb__deconvol__sync.html#a11989e4f2aaba7842b10c096dcc668a6", null ]
];