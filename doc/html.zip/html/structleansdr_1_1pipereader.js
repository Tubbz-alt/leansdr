var structleansdr_1_1pipereader =
[
    [ "pipereader", "structleansdr_1_1pipereader.html#adfd634f90ffc63a6db9edc6dec90a2e8", null ],
    [ "rd", "structleansdr_1_1pipereader.html#a43a7fbc4a52408c19e7a7e4989d2fa20", null ],
    [ "read", "structleansdr_1_1pipereader.html#a4c0c7a1148b2e107ca3559aa548303db", null ],
    [ "readable", "structleansdr_1_1pipereader.html#a918552352fece43b39ec3be30a0e5bae", null ],
    [ "buf", "structleansdr_1_1pipereader.html#a7014bd67c77088327dc8d9acbb8ed6f9", null ],
    [ "id", "structleansdr_1_1pipereader.html#a3381525e2f173a4982034015d717e5b9", null ]
];