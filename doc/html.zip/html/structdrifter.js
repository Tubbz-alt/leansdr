var structdrifter =
[
    [ "component", "structdrifter_1_1component.html", "structdrifter_1_1component" ],
    [ "drifter", "structdrifter.html#a43d446dec43dc6390ae69e98a842d765", null ],
    [ "run", "structdrifter.html#a226ed9a4696bd32aeae19cb718a7faf6", null ],
    [ "drifts", "structdrifter.html#ab2df2b89bda29b8f17183d16ee7c0c52", null ]
];