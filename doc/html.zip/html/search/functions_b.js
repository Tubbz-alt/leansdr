var searchData=
[
  ['naive_5flowpass',['naive_lowpass',['../structleansdr_1_1naive__lowpass.html#a0b4de7cdccd9d201efe163af8883bbb9',1,'leansdr::naive_lowpass']]],
  ['next_5fsync',['next_sync',['../structleansdr_1_1deconvol__sync.html#a73de36a8be9d747f8dd48356e3545188',1,'leansdr::deconvol_sync']]],
  ['normalize_5fdcgain',['normalize_dcgain',['../namespaceleansdr_1_1filtergen.html#a480e3e48fd65dd33a10a611abe0b6941',1,'leansdr::filtergen']]],
  ['normalize_5fpower',['normalize_power',['../namespaceleansdr_1_1filtergen.html#ac7d11609c534ce9b5aac2fa60275ea24',1,'leansdr::filtergen']]]
];
