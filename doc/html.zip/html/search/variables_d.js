var searchData=
[
  ['omega',['omega',['../structleansdr_1_1cstln__receiver.html#a1bf1721598ab19d46243a67bdfcfa9d6',1,'leansdr::cstln_receiver::omega()'],['../structleansdr_1_1fast__qpsk__receiver.html#a3ecdeeb1c4ddea9c94f9d9cd1b7da610',1,'leansdr::fast_qpsk_receiver::omega()']]],
  ['out_5frms',['out_rms',['../structleansdr_1_1simple__agc.html#a77792c0e24d5e0bc31caee06672ff88b',1,'leansdr::simple_agc']]],
  ['output_5fformat',['output_format',['../structconfig.html#a45bf34e5bbcd9667f80866d92a49d60d',1,'config']]]
];
