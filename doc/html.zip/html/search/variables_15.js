var searchData=
[
  ['x',['x',['../structleansdr_1_1window__placement.html#a594e409f23f8f63ac06bfa9ae3137c9f',1,'leansdr::window_placement']]]
];
