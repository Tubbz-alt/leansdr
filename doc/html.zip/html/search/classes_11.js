var searchData=
[
  ['wgn_5fc',['wgn_c',['../structleansdr_1_1wgn__c.html',1,'leansdr']]],
  ['window_5fplacement',['window_placement',['../structleansdr_1_1window__placement.html',1,'leansdr']]]
];
