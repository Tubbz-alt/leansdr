var searchData=
[
  ['dvb_5fs',['DVB_S',['../structconfig.html#aea1bee459621e44a174a258a2b275458a3ffb6db7bf1267f9651f6b4508c2c97a',1,'config']]],
  ['dvb_5fs2',['DVB_S2',['../structconfig.html#aea1bee459621e44a174a258a2b275458a732346534ac8cd1df2753292e1ca597a',1,'config']]]
];
