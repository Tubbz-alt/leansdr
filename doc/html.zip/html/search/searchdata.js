var indexSectionsWithContent =
{
  0: "abcdefghiklmnopqrstuvwxy",
  1: "abcdefghilmnprstvw",
  2: "l",
  3: "cdfghilmrsv",
  4: "abcdefghilmnoprstuvw",
  5: "abcdefghiklmnoprstuvwxy",
  6: "cdfhistu",
  7: "cdp",
  8: "abdfipqs",
  9: "adhl"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Macros"
};

