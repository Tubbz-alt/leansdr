var searchData=
[
  ['w',['w',['../structleansdr_1_1window__placement.html#a09d6396bf42f574bd98cc783469eea42',1,'leansdr::window_placement']]],
  ['want_5fsyncs',['want_syncs',['../structleansdr_1_1mpeg__sync.html#a6dfb6c8f0b0d50c207780fdcbfc28fb0',1,'leansdr::mpeg_sync']]],
  ['window_5fsize',['window_size',['../structleansdr_1_1ss__estimator.html#a2fd3aee39c2935afbbb744d4f84a7fbe',1,'leansdr::ss_estimator::window_size()'],['../structleansdr_1_1ss__amp__estimator.html#a54878dc59d01cda9db5e5ac3f67f15b4',1,'leansdr::ss_amp_estimator::window_size()']]],
  ['windows',['windows',['../structleansdr_1_1scheduler.html#a757a3630a691bd49074de6cb1358d54c',1,'leansdr::scheduler']]],
  ['wr',['wr',['../structleansdr_1_1pipebuf.html#ad18b60d7ba6612c4f1ce6c03c9474376',1,'leansdr::pipebuf']]]
];
