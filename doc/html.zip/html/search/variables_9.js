var searchData=
[
  ['k',['k',['../structleansdr_1_1auto__notch.html#af389bf792345a2046cbe680854eeebd0',1,'leansdr::auto_notch']]],
  ['kavg',['kavg',['../structleansdr_1_1cnr__fft.html#a79bc55924aa91d65b752f038dd68e18a',1,'leansdr::cnr_fft']]],
  ['kest',['kest',['../structleansdr_1_1cstln__receiver.html#add29ebe5b9a01595beb24f3db1ca9723',1,'leansdr::cstln_receiver']]]
];
