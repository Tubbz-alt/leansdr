var searchData=
[
  ['algebraic_5fcompat',['ALGEBRAIC_COMPAT',['../leandvb_8cc.html#a6be035784255035f7ed034b368719d0e',1,'leandvb.cc']]]
];
