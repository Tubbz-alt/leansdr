var searchData=
[
  ['naive_5flowpass',['naive_lowpass',['../structleansdr_1_1naive__lowpass.html',1,'leansdr']]],
  ['nearest_5fsampler',['nearest_sampler',['../structleansdr_1_1nearest__sampler.html',1,'leansdr']]]
];
