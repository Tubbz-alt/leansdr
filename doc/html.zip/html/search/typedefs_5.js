var searchData=
[
  ['s16',['s16',['../namespaceleansdr.html#aa05cd1faaa2220e2310736bcea2a74c9',1,'leansdr']]],
  ['s32',['s32',['../namespaceleansdr.html#a68c23c47befaaa84df4a4402e646b9ab',1,'leansdr']]],
  ['s8',['s8',['../namespaceleansdr.html#a613c332c47de51f3f0e079fa0d13f96c',1,'leansdr']]],
  ['s_5fangle',['s_angle',['../namespaceleansdr.html#ad07d5aeecc7338cb8452c8cadd7d4a7d',1,'leansdr']]],
  ['signal_5ft',['signal_t',['../structleansdr_1_1deconvol__sync.html#a6a3cfa2d5e77f922cc428a0533b3bb3e',1,'leansdr::deconvol_sync']]],
  ['statebank',['statebank',['../structleansdr_1_1viterbi__dec.html#a19fec5c6c575856a05b9f31d4db00c7b',1,'leansdr::viterbi_dec']]]
];
