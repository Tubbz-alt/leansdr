var searchData=
[
  ['y',['y',['../structleansdr_1_1window__placement.html#ac3b6e2417ef456591ed8c3e76512b631',1,'leansdr::window_placement']]]
];
