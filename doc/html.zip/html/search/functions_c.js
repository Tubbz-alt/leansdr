var searchData=
[
  ['operator_2a',['operator*',['../namespaceleansdr.html#a994b7e364ab62666621fe6f2f80be19d',1,'leansdr::operator*(const complex&lt; T &gt; &amp;a, const complex&lt; T &gt; &amp;b)'],['../namespaceleansdr.html#a7ac70d75e643c956ed2c6ef7a715cf32',1,'leansdr::operator*(const complex&lt; T &gt; &amp;a, const T &amp;k)'],['../namespaceleansdr.html#ac5515c1e0266450f5bc91d90f0b1a6ce',1,'leansdr::operator*(const T &amp;k, const complex&lt; T &gt; &amp;a)']]],
  ['operator_2b',['operator+',['../namespaceleansdr.html#a857b3a967a2c31d1051704d11df33ac9',1,'leansdr']]],
  ['operator_2b_3d',['operator+=',['../structleansdr_1_1complex.html#ae3ec65db8bdb4eafdf1b3282155b12c6',1,'leansdr::complex']]],
  ['opt_5fwritable',['opt_writable',['../namespaceleansdr.html#ac95af16d02125f5afb66f18cb52ea375',1,'leansdr']]],
  ['opt_5fwrite',['opt_write',['../namespaceleansdr.html#ab26a491d085f5c8a0e8765ca922e8385',1,'leansdr']]],
  ['opt_5fwriter',['opt_writer',['../namespaceleansdr.html#afc159975caf06a34bd5f7641ee75d5f9',1,'leansdr']]]
];
