var searchData=
[
  ['rds',['rds',['../structleansdr_1_1pipebuf.html#a29f1caf013f6782d0a239127d87fee84',1,'leansdr::pipebuf']]],
  ['re',['re',['../structleansdr_1_1complex.html#ab467907f973b42a094d687a605feeaa5',1,'leansdr::complex']]],
  ['resample',['resample',['../structconfig.html#a558e5feb5c1997a749455bd0e5a0e798',1,'config']]],
  ['resample_5frej',['resample_rej',['../structconfig.html#a50448b75dd503d8a3ae0bb5324686db9',1,'config']]],
  ['resync_5fperiod',['resync_period',['../structleansdr_1_1dvb__deconvol__sync.html#a11989e4f2aaba7842b10c096dcc668a6',1,'leansdr::dvb_deconvol_sync::resync_period()'],['../structleansdr_1_1mpeg__sync.html#a2673465a4a326c5653dc32014c5c6bfe',1,'leansdr::mpeg_sync::resync_period()'],['../structleansdr_1_1viterbi__sync.html#ab786c4ee701a2d0528d7553d684011f8',1,'leansdr::viterbi_sync::resync_period()'],['../structleansdr_1_1viterbi__sync__bpsk.html#ab0ff96735834bebee878e9267917ed4a',1,'leansdr::viterbi_sync_bpsk::resync_period()'],['../structleansdr_1_1hdlc__sync.html#a6a164c86a363c5d3c64157fb9b1f80f1',1,'leansdr::hdlc_sync::resync_period()']]],
  ['rewind',['rewind',['../structconfig.html#a85c11cbf0e4282020cf9e61305bc7274',1,'config']]],
  ['rlut_5fangles',['RLUT_ANGLES',['../structleansdr_1_1fast__qpsk__receiver.html#ab565b008e2d073f39d3886610b56d168',1,'leansdr::fast_qpsk_receiver']]],
  ['rlut_5fbits',['RLUT_BITS',['../structleansdr_1_1fast__qpsk__receiver.html#a12615cd1bdf1e2077ed3c0ae3683d8e9',1,'leansdr::fast_qpsk_receiver']]],
  ['rolloff',['rolloff',['../structconfig.html#a01285ec7db0e957940bfbbc33ea54b30',1,'config']]],
  ['rrc_5frej',['rrc_rej',['../structconfig.html#a7240c8dfbab6bcc96a80577d285725ea',1,'config']]],
  ['rrc_5fsteps',['rrc_steps',['../structconfig.html#a8c9df95eb8003ceebbc723dfe750a3a5',1,'config']]],
  ['rs',['rs',['../structleansdr_1_1rs__decoder.html#a3099e1f28f23c0101ae869611f1b470e',1,'leansdr::rs_decoder']]],
  ['runnables',['runnables',['../structleansdr_1_1scheduler.html#a7be1b919d03fcd6e0ec17bdbc944126d',1,'leansdr::scheduler']]]
];
