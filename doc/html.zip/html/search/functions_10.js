var searchData=
[
  ['trellis',['trellis',['../structleansdr_1_1trellis.html#a23f0bc778fce5983e5ea8136a3b753ee',1,'leansdr::trellis']]],
  ['trig16',['trig16',['../structleansdr_1_1trig16.html#ac581a54778113967127aac6929570ebc',1,'leansdr::trig16']]]
];
