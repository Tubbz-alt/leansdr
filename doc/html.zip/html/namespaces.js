var namespaces =
[
    [ "leansdr", "namespaceleansdr.html", "namespaceleansdr" ]
];