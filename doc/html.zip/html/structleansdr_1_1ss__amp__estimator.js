var structleansdr_1_1ss__amp__estimator =
[
    [ "ss_amp_estimator", "structleansdr_1_1ss__amp__estimator.html#a220fe2dd04ee61ed980f08cab3ecb897", null ],
    [ "run", "structleansdr_1_1ss__amp__estimator.html#a4f670222b7e33c63abaff9418ca6b3f2", null ],
    [ "decimation", "structleansdr_1_1ss__amp__estimator.html#a48f15e6510d880ec25686ad2d377a99d", null ],
    [ "window_size", "structleansdr_1_1ss__amp__estimator.html#a54878dc59d01cda9db5e5ac3f67f15b4", null ]
];